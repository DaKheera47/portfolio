const textToChange = document.getElementsByClassName("changing-text");
const totalOptions = [
    "shaheer sarfaraz",
    "A Programmer",
    "a student",
    "a web developer",
];
let i = 0;

setInterval(() => {
    if (totalOptions[i]) {
        anime({
            targets: ".changing-text",
            opacity: 0,
            duration: 200,
            direction: "alternate",
            changeComplete: () => {
                textToChange[0].textContent = totalOptions[i];
            },
            easing: "easeOutCubic",
        });

        i++;

        if (!totalOptions[i]) {
            i = 0;
        }
    }
}, 3000);
